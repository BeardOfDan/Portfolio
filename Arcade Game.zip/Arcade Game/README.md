frontend-nanodegree-arcade-game
===============================

**Quick Start**
_______________

Open the file "index.html" in your browser to start playing the game

**Instructions**
________________

This is a frogger game clone.
Your objective is to reach the water, but if you collide with a bug, you will be sent back to the start.
Every time you reach the objective, the speed of every enemy will slightly increase.
Every third time you reach the objective, an additional enemy will spawn.

You can control your character with the Arrow or wasd keys

Good luck!